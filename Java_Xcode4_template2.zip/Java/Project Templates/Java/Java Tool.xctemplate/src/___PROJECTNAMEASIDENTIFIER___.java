//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import java.util.*;

public class ___PROJECTNAMEASIDENTIFIER___ { 

    public static void main (String args[]) {
        // insert code here...
        System.out.println("Hello World!");
    }
}


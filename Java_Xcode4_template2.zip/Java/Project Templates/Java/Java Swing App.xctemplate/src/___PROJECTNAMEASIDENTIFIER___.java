//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import javax.swing.*;
import java.awt.*;

public class ___PROJECTNAMEASIDENTIFIER___ { 
    public static void main(String[] args) {
        //create the frame.  The constructor optionally takes
        //a string as an argument that's used as the title.
        JFrame frame = new JFrame("This is a test!");

        //set the size -- 300 by 300 is good
        int widthFrame = 300;
        int heightFrame = 300;
        frame.setSize(widthFrame, heightFrame);
        
        //create the Label. And Centered on the frame.
        JLabel lblText = new JLabel("Hello World!",SwingConstants.CENTER);
        frame.getContentPane().add(lblText, BorderLayout.CENTER);
        lblText.setPreferredSize(new Dimension(widthFrame, 100));
        
        //this next line is currently commented.  If you
        //uncomment it, the user will not be able to resize
        //the JFrame
        //frame.setResizable(false);
        
        //has the application exit when the frame is closed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //these lines are also commented, but you can uncomment
        //them to see their effects.  The first will center the
        //JFrame in the center of the screen.  The second will
        //make it the front, focused window.
        
        frame.setLocationRelativeTo(null);
        frame.toFront();
        
        //makes the frame visible.  The frame is invisible
        //until this method is called.
        frame.setVisible(true);
    }
}
